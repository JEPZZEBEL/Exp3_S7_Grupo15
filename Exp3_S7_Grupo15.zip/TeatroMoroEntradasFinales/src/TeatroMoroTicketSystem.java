import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TeatroMoroTicketSystem {
 
    private final String nombreTeatro;
    private final HashMap<String, Integer> preciosUbicaciones;
    private final int capacidadSala;
    private int entradasDisponibles;

    private static int totalIngresos = 0;
    private static int totalEntradasVendidas = 0;

    // Lista para almacenar las ventas
    private final ArrayList<Venta> ventas = new ArrayList<>();

    // Constructor
    public TeatroMoroTicketSystem(String nombreTeatro, HashMap<String, Integer> preciosUbicaciones, int capacidadSala, int entradasDisponibles) {
        this.nombreTeatro = nombreTeatro;
        this.preciosUbicaciones = preciosUbicaciones;
        this.capacidadSala = capacidadSala;
        this.entradasDisponibles = entradasDisponibles;
    }

    //  menu interactivo
    public void mostrarMenu() {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean salir = false;
            while (!salir) {
                System.out.println("---- Menu ----");
                System.out.println("1. Venta de entradas");
                System.out.println("2. Visualizar resumen de ventas");
                System.out.println("3. Generar boleta");
                System.out.println("4. Calcular Ingresos Totales");
                System.out.println("5. Salir del Programa");
                System.out.print("Seleccione una opcion: ");
                int opcion;
                try {
                    opcion = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Debe ingresar un numero.");
                    scanner.nextLine(); // Limpiar el buffer del scanner
                    continue;
                }
                switch (opcion) {
                    case 1 -> ventaEntradas(scanner);
                    case 2 -> visualizarResumenVentas();
                    case 3 -> generarBoleta();
                    case 4 -> calcularIngresosTotales();
                    case 5 -> {
                        System.out.println("Gracias por su compra");
                        salir = true;
                    }
                    default -> System.out.println("Opcion no valida");
                }
            }
        }
    }

    // venta de entradas
    private void ventaEntradas(Scanner scanner) {
        System.out.println("---- Venta de Entradas ----");
        System.out.print("Seleccione la ubicacion (VIP, Platea, Balcon): ");
        String ubicacion = scanner.next();
        Integer precioBase = preciosUbicaciones.get(ubicacion);

        if (precioBase == null) {
            System.out.println("Ubicacion no valida");
            return;
        }

        System.out.print(" Es estudiante? (SI/NO): ");
        boolean esEstudiante = scanner.next().equalsIgnoreCase("si");
        System.out.print("Es de la tercera edad? (SI/NO): ");
        boolean esPersonaMayor = scanner.next().equalsIgnoreCase("si");

        int descuento = 0;
        if (esEstudiante) {
            descuento = 10;
        } else if (esPersonaMayor) {
            descuento = 15;
        }

        int costoFinal = precioBase - (precioBase * descuento / 100);

        //disponibilidad de entradas
        if (entradasDisponibles > 0) {
            entradasDisponibles--;
            totalEntradasVendidas++;
            totalIngresos += costoFinal;
            ventas.add(new Venta(ubicacion, costoFinal, descuento));
            System.out.println(" Venta realizada con Exito!");
        } else {
            System.out.println("Lo siento, no quedan entradas disponibles para esta ubicacion.");
        }
    }

    // resumen de ventas
    private void visualizarResumenVentas() {
        System.out.println("---- Resumen de Ventas ----");
        for (Venta venta : ventas) {
            System.out.println("Ubicacion: " + venta.ubicacion);
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("--------------------------");
        }
    }

    // generar la boleta
    private void generarBoleta() {
        System.out.println("-------------------------");
        System.out.println("      TEATRO MORO     ");
        System.out.println("-------------------------");
        System.out.println("        Boleta         ");
        System.out.println("-------------------------");
        for (Venta venta : ventas) {
            System.out.println("Ubicacion: " + venta.ubicacion);
            System.out.println("Costo Base: " + preciosUbicaciones.get(venta.ubicacion));
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("--------------------------");
            System.out.println("  Gracias por su compra   ");
            System.out.println("--------------------------");
        }
    }

    // ingresos totales
    private void calcularIngresosTotales() {
        System.out.println("Ingresos Totales: " + totalIngresos);
    }

    // Clase interna para representar una venta
    private class Venta {
        private String ubicacion;
        private int costoFinal;
        private int descuento;

        public Venta(String ubicacion, int costoFinal, int descuento) {
            this.ubicacion = ubicacion;
            this.costoFinal = costoFinal;
            this.descuento = descuento;
        }
    }

    // Método main
    public static void main(String[] args) {
        HashMap<String, Integer> preciosUbicaciones = new HashMap<>();
        preciosUbicaciones.put("VIP", 200000);
        preciosUbicaciones.put("Platea", 150000);
        preciosUbicaciones.put("Balcon", 100000);

        TeatroMoroTicketSystem sistema = new TeatroMoroTicketSystem("Teatro Moro", preciosUbicaciones, 50, 50);
        sistema.mostrarMenu();
    }
}
